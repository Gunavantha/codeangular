# angular-4-demo-app
Angular v4.0 Demo App with CRUD functionality
