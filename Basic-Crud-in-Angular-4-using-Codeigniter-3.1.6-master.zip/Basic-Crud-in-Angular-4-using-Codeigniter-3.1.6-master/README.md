# Basic-Crud-in-Angular-4-using-Codeigniter-3.1.6 
Only I made Basic works for Beginners learn from it 

Learn Basic of Angular 4 from this Video tutorial then download this project 
https://www.youtube.com/watch?v=KhzGSHNhnbI&list=PLillGF-RfqbYeckUaD1z6nviTp31GLTH8


After download this demo work 

Import the Sql file i zttached in it in tha name of Db angular_four
Then 
goto the path of your_file_path/ api/ng4 in your Command prompt or Git Bash whatever


__Build and serve it__

```
npm install

npm start 
ng serve 
```

Visit http://localhost:4200 and you should see "app works!"


